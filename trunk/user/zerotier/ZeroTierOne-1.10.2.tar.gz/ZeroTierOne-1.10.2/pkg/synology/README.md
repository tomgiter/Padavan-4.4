## Package for Synology's DSM 6

Documentation and downloads: [docs.zerotier.com/devices/synology](https://docs.zerotier.com/devices/synology)


```
./build.sh build
```
